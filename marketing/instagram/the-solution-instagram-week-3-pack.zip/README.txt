The Solution, Instagram week 3 (15-21 Oct). One folder per day: media in posting order, caption.txt to paste, story.jpg (carousel days) or reuse the Reel as the Story. Post at 15:00 UK time.
